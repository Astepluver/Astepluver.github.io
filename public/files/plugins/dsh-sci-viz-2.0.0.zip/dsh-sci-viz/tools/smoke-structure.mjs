/** 结构解析器冒烟测试：解析工作区里真实的 PDB / mmCIF，检查文档尺寸与字段。 */
import { readFileSync, statSync } from 'node:fs'
import { parseStructure, compileStructure, parseSiteSpec } from '../lib/core/structure.js'

const FILES = [
  ['C:/Users/29411/dsh/.tmp_read/AF_O53740.pdb', 'pdb'],
  ['C:/Users/29411/dsh/.tmp_read/AF_P9WJV1.pdb', 'pdb'],
  ['C:/Users/29411/dsh/.tmp_read/af3/fold_2304plus3unit_model_0.cif', 'mmcif'],
  ['C:/Users/29411/dsh/.tmp_read/af3b/fold_2dvar_model_0.cif', 'mmcif'],
]

let failed = 0
for (const [path, format] of FILES) {
  try {
    const bytes = statSync(path).size
    const text = readFileSync(path, 'utf8')
    const t0 = Date.now()
    const parsed = parseStructure(text, format)
    const doc = compileStructure(parsed, {
      path,
      format,
      bytes,
      label: path.split('/').pop(),
      sourceId: '',
    })
    const ms = Date.now() - t0
    const json = JSON.stringify(doc)
    console.log(
      `${path.split('/').pop().padEnd(34)} ${format.padEnd(6)} ` +
      `in=${(bytes / 1024).toFixed(0)}KB out=${(json.length / 1024).toFixed(0)}KB ` +
      `atoms=${doc.atoms.count} res=${doc.stats.residues} chains=${doc.stats.chains} ` +
      `lig=${doc.stats.ligands} ss=${doc.stats.ssSource} R=${doc.source.resolution ?? '-'} ` +
      `t=${ms}ms`,
    )
    if (doc.atoms.count === 0) throw new Error('原子数为 0')
    if (doc.ca.length === 0) throw new Error('没有 Cα 原子')
    if (!Number.isFinite(doc.bbox.radius) || doc.bbox.radius <= 0) throw new Error('包围盒半径异常')
    const chain = doc.chains.find((c) => c.residueCount > 4)
    if (chain) console.log(`    chain ${chain.id}: ${chain.residueCount} res, seq[:60]=${chain.seq.slice(0, 60)}`)
  } catch (e) {
    failed += 1
    console.log(`FAIL ${path}: ${e.message}`)
  }
}

// 位点写法解析
const SITES = ['S315T', 's315t', 'S315', '315', 'D94G', 'A:315', 'A:S315T', 'katG S315T', '']
console.log('\n位点解析:')
for (const s of SITES) console.log(`  ${JSON.stringify(s).padEnd(14)} -> ${JSON.stringify(parseSiteSpec(s))}`)

process.exit(failed ? 1 : 0)
