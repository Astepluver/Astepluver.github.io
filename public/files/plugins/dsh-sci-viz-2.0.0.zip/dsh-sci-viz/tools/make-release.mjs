/**
 * 打一个规范的发布包：dist/dsh-sci-viz-<version>.zip
 *
 * 自己实现 ZIP 写入（约 100 行），不引任何依赖 —— 和插件本身「零依赖」的原则一致，
 * 也避免依赖 PowerShell 的 Compress-Archive（那个对路径与编码的处理不透明）。
 *
 * 包内结构：
 *   dsh-sci-viz/
 *     package.json  cordis.patch.yml  README.md  LICENSE  CHANGELOG.md
 *     lib/…  data/…  tools/…
 *
 * 不含 state/（运行期产物，每次覆盖，不该随包分发）。
 *
 * 用法：node tools/make-release.mjs [--out=目录]
 */
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, existsSync, rmSync } from 'node:fs'
import { deflateRawSync, gzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
import { join, dirname, relative, basename } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const P = join(HERE, '..')
const pkg = JSON.parse(readFileSync(join(P, 'package.json'), 'utf8'))
const NAME = pkg.name
const VERSION = pkg.version

const outArg = process.argv.slice(2).find((a) => a.startsWith('--out='))
const OUT_DIR = outArg ? outArg.slice(6) : join(P, 'dist')

// ---- 收集要打包的文件 -------------------------------------------------------
const INCLUDE_FILES = ['package.json', 'cordis.patch.yml', 'README.md', 'LICENSE', 'CHANGELOG.md', '功能清单.md']
const INCLUDE_DIRS = ['lib', 'data', 'tools']
const EXCLUDE = [/^state\//, /\.tmp\//, /\/\.tmp\//, /node_modules\//, /\.zip$/, /_session-decoded/, /^dist\//]

const files = []
const add = (abs, rel) => {
  if (EXCLUDE.some((re) => re.test(rel))) return
  files.push({ abs, rel })
}
const walk = (abs, rel) => {
  for (const e of readdirSync(abs, { withFileTypes: true })) {
    const childAbs = join(abs, e.name)
    const childRel = rel ? `${rel}/${e.name}` : e.name
    if (e.isDirectory()) walk(childAbs, childRel)
    else if (e.name.startsWith('_')) continue // 临时脚本
    else add(childAbs, childRel)
  }
}
for (const f of INCLUDE_FILES) {
  if (existsSync(join(P, f))) add(join(P, f), f)
}
for (const d of INCLUDE_DIRS) {
  if (existsSync(join(P, d))) walk(join(P, d), d)
}
files.sort((a, b) => (a.rel < b.rel ? -1 : 1))

// ---- 最小 ZIP 写入 ----------------------------------------------------------
const CRC_TABLE = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()

function crc32(buf) {
  let c = -1
  for (let i = 0; i < buf.length; i += 1) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ -1) >>> 0
}

/** DOS 时间戳（ZIP 用的是这个古老格式）。 */
function dosTime(d) {
  const time = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() / 2)) & 0xffff
  const date = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xffff
  return { time, date }
}

const now = new Date()
const { time: dosT, date: dosD } = dosTime(now)
const locals = []
const centrals = []
let offset = 0

for (const f of files) {
  const raw = readFileSync(f.abs)
  const deflated = deflateRawSync(raw, { level: 9 })
  // 已经压过的（.gz）再 deflate 只会更大，那就原样存
  const useDeflate = deflated.length < raw.length
  const body = useDeflate ? deflated : raw
  const method = useDeflate ? 8 : 0
  const name = Buffer.from(`${NAME}/${f.rel}`, 'utf8')
  const crc = crc32(raw)
  const { time, date } = dosTime(statSync(f.abs).mtime)

  const local = Buffer.alloc(30)
  local.writeUInt32LE(0x04034b50, 0)
  local.writeUInt16LE(20, 4) // version needed
  local.writeUInt16LE(0x0800, 6) // 文件名用 UTF-8
  local.writeUInt16LE(method, 8)
  local.writeUInt16LE(time, 10)
  local.writeUInt16LE(date, 12)
  local.writeUInt32LE(crc, 14)
  local.writeUInt32LE(body.length, 18)
  local.writeUInt32LE(raw.length, 22)
  local.writeUInt16LE(name.length, 26)
  local.writeUInt16LE(0, 28)
  locals.push(local, name, body)

  const central = Buffer.alloc(46)
  central.writeUInt32LE(0x02014b50, 0)
  central.writeUInt16LE(20, 4) // version made by
  central.writeUInt16LE(20, 6) // version needed
  central.writeUInt16LE(0x0800, 8)
  central.writeUInt16LE(method, 10)
  central.writeUInt16LE(time, 12)
  central.writeUInt16LE(date, 14)
  central.writeUInt32LE(crc, 16)
  central.writeUInt32LE(body.length, 20)
  central.writeUInt32LE(raw.length, 24)
  central.writeUInt16LE(name.length, 28)
  central.writeUInt16LE(0, 30) // extra
  central.writeUInt16LE(0, 32) // comment
  central.writeUInt16LE(0, 34) // disk
  central.writeUInt16LE(0, 36) // internal attrs
  central.writeUInt32LE((0o100644 << 16) >>> 0, 38) // 权限：普通文件（>>> 0 避免 32 位有符号溢出）
  central.writeUInt32LE(offset, 42)
  centrals.push(central, name)

  offset += local.length + name.length + body.length
}

const centralBuf = Buffer.concat(centrals)
const eocd = Buffer.alloc(22)
eocd.writeUInt32LE(0x06054b50, 0)
eocd.writeUInt16LE(0, 4)
eocd.writeUInt16LE(0, 6)
eocd.writeUInt16LE(files.length, 8)
eocd.writeUInt16LE(files.length, 10)
eocd.writeUInt32LE(centralBuf.length, 12)
eocd.writeUInt32LE(offset, 16)
eocd.writeUInt16LE(0, 20)

const zip = Buffer.concat([...locals, centralBuf, eocd])

// ---- 写出 -------------------------------------------------------------------
mkdirSync(OUT_DIR, { recursive: true })
const zipPath = join(OUT_DIR, `${NAME}-${VERSION}.zip`)
writeFileSync(zipPath, zip)
const sha = createHash('sha256').update(zip).digest('hex')
writeFileSync(join(OUT_DIR, `${NAME}-${VERSION}.sha256.txt`),
  `${sha}  ${basename(zipPath)}\n`, 'utf8')

// ---- 报告 -------------------------------------------------------------------
const byDir = new Map()
for (const f of files) {
  const top = f.rel.includes('/') ? f.rel.split('/')[0] : '(根目录)'
  const cur = byDir.get(top) ?? { n: 0, bytes: 0 }
  cur.n += 1
  cur.bytes += statSync(f.abs).size
  byDir.set(top, cur)
}
console.log(`${NAME} ${VERSION}`)
console.log(`文件 ${files.length} 个`)
for (const [k, v] of [...byDir.entries()].sort()) {
  console.log(`  ${k.padEnd(18)} ${String(v.n).padStart(3)} 个   ${(v.bytes / 1024).toFixed(1).padStart(8)} KB`)
}
console.log(`\n${zipPath}`)
console.log(`  ${(zip.length / 1024).toFixed(0)} KB   sha256 ${sha}`)
