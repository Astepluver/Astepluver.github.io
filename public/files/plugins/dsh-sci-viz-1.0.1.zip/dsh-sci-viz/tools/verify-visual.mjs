/**
 * dsh-sci-viz 视觉验证：把浏览器端的绘制代码原样录成 SVG，再光栅化成 PNG。
 *
 * 为什么这么做：客户端渲染器是命令式的 canvas 代码，Node 里没有 canvas。
 * 但它的绘制调用只用一个受限子集，所以可以用一个「Canvas2D → SVG 记录器」把调用
 * 原样翻译成矢量图 —— 画出来的东西与浏览器里是同一套坐标与同一套指令，
 * 于是「我」能用 read_image 真正看到画面，而不是靠猜。
 *
 * 用法：
 *   node tools/verify-visual.mjs            # 输出到 .tmp/visual/*.svg 与 *.png
 * 光栅化用 profile 里的 sharp（resvg/vips，支持中日韩字形）。
 */
import { createRequire } from 'node:module'
import { mkdirSync, writeFileSync, readFileSync, rmSync, mkdtempSync, existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { tmpdir } from 'node:os'

const HERE = dirname(fileURLToPath(import.meta.url))
const OUT = join(HERE, '..', '.tmp', 'visual')
mkdirSync(OUT, { recursive: true })

// ---------------------------------------------------------------------------
// Canvas2D → SVG 记录器
// ---------------------------------------------------------------------------

const MAT = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 }
const mul = (m, n) => ({
  a: m.a * n.a + m.c * n.b,
  b: m.b * n.a + m.d * n.b,
  c: m.a * n.c + m.c * n.d,
  d: m.b * n.c + m.d * n.d,
  e: m.a * n.e + m.c * n.f + m.e,
  f: m.b * n.e + m.d * n.f + m.f,
})

const esc = (s) => String(s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

/** 粗略文本宽度：CJK 按 1.0em，其余按 0.55em —— 只用于验证版式是否合理。 */
function textWidth(text, size) {
  let units = 0
  for (const ch of String(text)) units += /[\u2e80-\u9fff\uff00-\uffef]/.test(ch) ? 1 : 0.55
  return units * size
}

class Gradient {
  constructor(kind, args, ctx) {
    this.kind = kind
    this.args = args
    this.ctx = ctx
    this.stops = []
    this.id = `grad${ctx.nextId()}`
  }

  addColorStop(offset, color) {
    this.stops.push([offset, color])
  }

  def() {
    const stops = this.stops.map(([o, c]) => `<stop offset="${o}" stop-color="${c}"/>`).join('')
    if (this.kind === 'linear') {
      const [x0, y0, x1, y1] = this.args
      return `<linearGradient id="${this.id}" gradientUnits="userSpaceOnUse" x1="${x0}" y1="${y0}" x2="${x1}" y2="${y1}">${stops}</linearGradient>`
    }
    const [x0, y0, r0, x1, y1, r1] = this.args
    return `<radialGradient id="${this.id}" gradientUnits="userSpaceOnUse" cx="${x1}" cy="${y1}" r="${r1}" fx="${x0}" fy="${y0}">${stops}</radialGradient>`
  }
}

/** 一个只实现浏览器端用到的子集的 CanvasRenderingContext2D。 */
class SvgContext {
  constructor(width, height) {
    this.width = width
    this.height = height
    this.m = { ...MAT }
    this.stack = []
    this.body = []
    this.defs = []
    this.idSeq = 0
    this.fillStyle = '#000'
    this.strokeStyle = '#000'
    this.lineWidth = 1
    this.globalAlpha = 1
    this.font = '10px sans-serif'
    this.textAlign = 'left'
    this.textBaseline = 'alphabetic'
    this.lineCap = 'butt'
    this.lineJoin = 'miter'
    this.dash = []
    this.path = []
    this.cur = null
    this.clipId = null
    this.unsupported = new Set()
  }

  nextId() {
    this.idSeq += 1
    return `g${this.idSeq}`
  }

  // ---- 状态 ----
  save() {
    this.stack.push({
      m: { ...this.m }, fillStyle: this.fillStyle, strokeStyle: this.strokeStyle,
      lineWidth: this.lineWidth, globalAlpha: this.globalAlpha, font: this.font,
      textAlign: this.textAlign, textBaseline: this.textBaseline,
      lineCap: this.lineCap, lineJoin: this.lineJoin, dash: this.dash.slice(), clipId: this.clipId,
    })
  }

  restore() {
    const s = this.stack.pop()
    if (!s) return
    this.m = s.m
    this.fillStyle = s.fillStyle
    this.strokeStyle = s.strokeStyle
    this.lineWidth = s.lineWidth
    this.globalAlpha = s.globalAlpha
    this.font = s.font
    this.textAlign = s.textAlign
    this.textBaseline = s.textBaseline
    this.lineCap = s.lineCap
    this.lineJoin = s.lineJoin
    this.dash = s.dash
    this.clipId = s.clipId
  }

  setTransform(a, b, c, d, e, f) {
    this.m = { a, b, c, d, e, f }
  }

  translate(x, y) {
    this.m = mul(this.m, { ...MAT, e: x, f: y })
  }

  rotate(rad) {
    const c = Math.cos(rad)
    const s = Math.sin(rad)
    this.m = mul(this.m, { a: c, b: s, c: -s, d: c, e: 0, f: 0 })
  }

  scale(x, y) {
    this.m = mul(this.m, { a: x, b: 0, c: 0, d: y, e: 0, f: 0 })
  }

  // ---- 样式 ----
  createLinearGradient(x0, y0, x1, y1) {
    const gr = new Gradient('linear', [x0, y0, x1, y1], this)
    this.pending = gr
    return gr
  }

  createRadialGradient(x0, y0, r0, x1, y1, r1) {
    const gr = new Gradient('radial', [x0, y0, r0, x1, y1, r1], this)
    this.pending = gr
    return gr
  }

  setLineDash(arr) {
    this.dash = arr || []
  }

  measureText(text) {
    const size = parseFloat(/([\d.]+)px/.exec(this.font)?.[1] ?? '10')
    return { width: textWidth(text, size) }
  }

  // ---- 路径 ----
  beginPath() {
    this.path = []
    this.cur = null
  }

  moveTo(x, y) {
    this.cur = { pts: [[x, y]], closed: false }
    this.path.push(this.cur)
  }

  lineTo(x, y) {
    if (!this.cur) this.moveTo(x, y)
    else this.cur.pts.push([x, y])
  }

  closePath() {
    if (this.cur) this.cur.closed = true
  }

  rect(x, y, w, h) {
    this.cur = { pts: [[x, y], [x + w, y], [x + w, y + h], [x, y + h]], closed: true }
    this.path.push(this.cur)
  }

  arc(cx, cy, r, a0, a1, ccw) {
    const full = Math.abs(Math.abs(a1 - a0) - Math.PI * 2) < 1e-6
    if (full) {
      const seg = { circle: [cx, cy, r], pts: [], closed: true }
      this.path.push(seg)
      this.cur = seg
      return
    }
    const steps = 24
    const start = ccw ? a1 : a0
    const end = ccw ? a0 : a1
    const sub = { pts: [], closed: false }
    for (let i = 0; i <= steps; i += 1) {
      const a = start + ((end - start) * i) / steps
      sub.pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)])
    }
    this.path.push(sub)
    this.cur = sub
  }

  clip() {
    const d = this.pathData()
    if (!d) return
    const id = `clip${this.nextId()}`
    this.defs.push(`<clipPath id="${id}" clipPathUnits="userSpaceOnUse"><path d="${d}"/></clipPath>`)
    this.clipId = id
  }

  pathData() {
    const parts = []
    for (const sub of this.path) {
      if (sub.circle) {
        const [cx, cy, r] = sub.circle
        parts.push(`M ${cx - r} ${cy} A ${r} ${r} 0 1 0 ${cx + r} ${cy} A ${r} ${r} 0 1 0 ${cx - r} ${cy} Z`)
        continue
      }
      if (!sub.pts.length) continue
      parts.push(`M ${sub.pts.map((p) => `${round(p[0])} ${round(p[1])}`).join(' L ')}`)
      if (sub.closed) parts.push('Z')
    }
    return parts.join(' ')
  }

  // ---- 绘制 ----
  paint(style) {
    if (style instanceof Gradient) return `url(#${style.id})`
    return style
  }

  attr(extra = '') {
    const alpha = this.globalAlpha < 1 ? ` opacity="${round(this.globalAlpha, 3)}"` : ''
    const clip = this.clipId ? ` clip-path="url(#${this.clipId})"` : ''
    return ` transform="matrix(${round(this.m.a, 6)} ${round(this.m.b, 6)} ${round(this.m.c, 6)} ${round(this.m.d, 6)} ${round(this.m.e, 3)} ${round(this.m.f, 3)})"${alpha}${clip}${extra}`
  }

  registerGradient(style) {
    if (style instanceof Gradient) this.defs.push(style.def())
    return this.paint(style)
  }

  fill() {
    const d = this.pathData()
    if (!d) return
    this.body.push(`<path d="${d}" fill="${this.registerGradient(this.fillStyle)}" ${this.attr()}/>`)
  }

  stroke() {
    const d = this.pathData()
    if (!d) return
    const dash = this.dash.length ? ` stroke-dasharray="${this.dash.join(' ')}"` : ''
    this.body.push(
      `<path d="${d}" fill="none" stroke="${this.registerGradient(this.strokeStyle)}" stroke-width="${round(this.lineWidth, 3)}"` +
      ` stroke-linecap="${this.lineCap}" stroke-linejoin="${this.lineJoin}"${dash} ${this.attr()}/>`,
    )
  }

  fillRect(x, y, w, h) {
    if (!(w > 0) && !(h > 0)) return
    this.body.push(
      `<rect x="${round(x, 3)}" y="${round(y, 3)}" width="${round(Math.abs(w), 3)}" height="${round(Math.abs(h), 3)}"` +
      ` fill="${this.registerGradient(this.fillStyle)}" ${this.attr()}/>`,
    )
  }

  strokeRect(x, y, w, h) {
    this.body.push(
      `<rect x="${round(x, 3)}" y="${round(y, 3)}" width="${round(Math.abs(w), 3)}" height="${round(Math.abs(h), 3)}"` +
      ` fill="none" stroke="${this.registerGradient(this.strokeStyle)}" stroke-width="${round(this.lineWidth, 3)}" ${this.attr()}/>`,
    )
  }

  clearRect() {
    /* 背景随后会被 fillRect 覆盖，验证图里可以忽略 */
  }

  fillText(text, x, y) {
    const size = parseFloat(/([\d.]+)px/.exec(this.font)?.[1] ?? '10')
    const weight = /(\d00|bold)/.test(this.font) ? (/bold/.test(this.font) ? '700' : /(\d00)/.exec(this.font)[1]) : '400'
    const family = this.font.replace(/^[^ ]+ /, '').replace(/^\d+ /, '')
    const anchor = this.textAlign === 'center' ? 'middle' : this.textAlign === 'right' ? 'end' : 'start'
    const baseline = this.textBaseline === 'middle' ? 'central'
      : this.textBaseline === 'top' ? 'hanging' : 'alphabetic'
    this.body.push(
      `<text x="${round(x, 2)}" y="${round(y, 2)}" fill="${this.registerGradient(this.fillStyle)}"` +
      ` font-size="${round(size, 2)}" font-weight="${weight}" font-family="${esc(family)}"` +
      ` text-anchor="${anchor}" dominant-baseline="${baseline}" ${this.attr()}>${esc(text)}</text>`,
    )
  }

  strokeText(text, x, y) {
    this.fillText(text, x, y)
  }

  /** 未实现的方法：记下来，验证时报警而不是静默画错。 */
  unsupportedCall(name) {
    this.unsupported.add(name)
  }

  toSvg() {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${this.width}" height="${this.height}" viewBox="0 0 ${this.width} ${this.height}">` +
      `<defs>${this.defs.join('')}</defs>` +
      `<rect width="${this.width}" height="${this.height}" fill="#0f1318"/>` +
      this.body.join('\n') +
      '</svg>'
  }
}

const round = (v, digits = 2) => {
  const f = Math.pow(10, digits)
  return Math.round(v * f) / f
}

// 未实现的方法挂上去，画到就报警
for (const name of ['drawImage', 'createPattern', 'fillText2', 'ellipse', 'roundRect', 'bezierCurveTo', 'quadraticCurveTo', 'setTransform2', 'filter']) {
  if (!(name in SvgContext.prototype)) SvgContext.prototype[name] = function () { this.unsupportedCall(name) }
}

/** 包一层 Proxy：用到没实现的方法就抛错（越早发现越好）。 */
function guardContext(ctx) {
  return new Proxy(ctx, {
    get(target, prop) {
      const value = target[prop]
      if (value === undefined && typeof prop === 'string') {
        throw new Error(`渲染器调用了 SvgContext 未实现的成员：${prop}（验证脚本需要补上它）`)
      }
      return typeof value === 'function' ? value.bind(target) : value
    },
  })
}

// ---------------------------------------------------------------------------
// 载入浏览器端代码
// ---------------------------------------------------------------------------

let captured = null
globalThis.window = {
  __ModuleLoader__: {
    load({ id, factory }) {
      captured = { id, exports: factory(() => { throw new Error('client bundle must not require anything') }) }
    },
  },
}
globalThis.document = { createElement: () => ({ style: {}, dataset: {}, appendChild() {}, querySelector: () => null }) }

const clientPath = join(HERE, '..', 'lib', 'client.js')
await import(`file://${clientPath.replace(/\\/g, '/')}`)
if (!captured) throw new Error('client.js 没有调用 window.__ModuleLoader__.load')
const internals = captured.exports.__internals
const EXPORTED = Object.keys(captured.exports)
console.log(`client bundle id = ${captured.id}`)
console.log(`client exports = ${EXPORTED.join(', ')}`)
console.log(`internals = ${Object.keys(internals).join(', ')}`)

// ---------------------------------------------------------------------------
// 产出可视化工件
// ---------------------------------------------------------------------------

const sharp = createRequire('C:/Users/29411/.dsh/profiles/desktop/package.json')('sharp')
const W = 1100
const H = 700
const artifacts = []

async function emit(name, svg) {
  const svgPath = join(OUT, `${name}.svg`)
  const pngPath = join(OUT, `${name}.png`)
  writeFileSync(svgPath, svg)
  const png = await sharp(Buffer.from(svg)).png().toBuffer()
  writeFileSync(pngPath, png)
  artifacts.push({ name, svg: svgPath, png: pngPath, bytes: png.length })
  return pngPath
}

/** 渲染一份结构文档。 */
async function renderStructure(doc, name, width = W, height = H) {
  internals.resetGradientCache()
  const g = guardContext(new SvgContext(width, height))
  const view = internals.createStructureView(doc)
  internals.paintStructure(g, view, width, height)
  if (g.unsupported.size) throw new Error(`结构渲染用到未实现方法：${[...g.unsupported].join(', ')}`)
  return emit(name, g.toSvg())
}

/** 渲染一份图表文档。 */
async function renderChart(doc, name, width = W, height = H) {
  internals.resetGradientCache()
  const g = guardContext(new SvgContext(width, height))
  internals.paintChart(g, doc, width, height)
  if (g.unsupported.size) throw new Error(`图表渲染用到未实现方法：${[...g.unsupported].join(', ')}`)
  return emit(name, g.toSvg())
}

// ---- 造真数据：用宿主工具产出的真实文档 ---------------------------------
const sandbox = mkdtempSync(join(tmpdir(), 'sciviz-visual-'))

/**
 * `--live`：直接渲染 state/current.json 里那一份「线上文档」。
 *
 * 用途是复现「面板上一片空白」这类只在真实文档上出现的问题 —— 浏览器里 poll()
 * 的 catch 会把渲染异常吞掉，画面就只是空的，什么线索都没有；在这里能拿到完整栈。
 */
if (process.argv.includes('--live')) {
  const statePath = join(HERE, '..', 'state', 'current.json')
  if (!existsSync(statePath)) {
    console.log(`没有 ${statePath}`)
    process.exit(1)
  }
  const doc = JSON.parse(readFileSync(statePath, 'utf8')).doc
  // 尺寸可以指定：面板里画布多高是可变的，「空白画布」常常是高度不够而不是没数据
  const sizeArg = process.argv.find((a) => a.startsWith('--size='))
  const [lw, lh] = sizeArg ? sizeArg.slice(7).split('x').map(Number) : [W, H]
  console.log(`线上文档：kind=${doc.kind} title=${doc.title}`)
  console.log(`panels=${doc.panels ? doc.panels.length : '-'} table=${doc.table ? doc.table.rows.length + ' 行' : '-'}`)
  console.log(`渲染尺寸：${lw}×${lh}`)
  try {
    if (doc.kind === 'chart') await renderChart(doc, 'live', lw, lh)
    else if (doc.kind === 'structure') await renderStructure(doc, 'live', lw, lh)
    else {
      console.log(`  不认识的 kind：${doc.kind}`)
      process.exit(2)
    }
    console.log('  ✓ 渲染成功，没有抛异常')
    console.log(`  产物：${OUT}\\live.png`)
  } catch (e) {
    console.log('  ✗ 渲染抛异常：')
    console.log(`    ${e && e.constructor ? e.constructor.name : 'Error'}: ${e && e.message}`)
    console.log(String(e && e.stack).split('\n').slice(1, 8).map((l) => '    ' + l.trim()).join('\n'))
    process.exit(3)
  }
  process.exit(0)
}

const toolDocs = new Map()
const tools = new Map()

const fakeCtx = {
  logger: { warn() {}, info() {}, error() {} },
  effect(body) { return body() },
  get: (n) => (n === 'tools' ? { register: (def) => { tools.set(def.name, def); return () => {} } } : undefined),
  webServer: { register: () => () => {} },
}

const host = await import(`file://${join(HERE, '..', 'lib', 'index.js').replace(/\\/g, '/')}`)
const N = await import(`file://${join(HERE, '..', 'lib', 'core', 'numeric.js').replace(/\\/g, '/')}`)
host.apply(fakeCtx, { stateDir: join(sandbox, 'state') })
await new Promise((r) => setTimeout(r, 500))

const runTool = async (name, args) => {
  const def = tools.get(name)
  if (!def) throw new Error(`工具没注册：${name}`)
  const value = await def.execute(args, {})
  const payload = JSON.parse(readFileSync(join(sandbox, 'state', 'current.json'), 'utf8'))
  toolDocs.set(name, payload.doc)
  return { value, doc: payload.doc }
}

console.log('\n== 生成结构画面 ==')
const pdbPath = 'C:/Users/29411/dsh/.tmp_read/AF_P9WJV1.pdb'
const structRun = await runTool('sci_viz_structure', {
  source: pdbPath,
  label: 'AF_P9WJV1（964 残基测试结构）',
})
const baseDoc = toolDocs.get('sci_viz_structure')
await renderStructure(baseDoc, 'structure-cartoon')

for (const style of ['trace', 'spacefill', 'ballstick']) {
  const doc = { ...baseDoc, view: { ...baseDoc.view, style } }
  await renderStructure(doc, `structure-${style}`)
}
{
  const doc = { ...baseDoc, view: { ...baseDoc.view, style: 'cartoon', colorBy: 'ss' } }
  await renderStructure(doc, 'structure-cartoon-ss')
}

// 高亮 + 配体：换一个小一点的结构，并高亮几个残基
{
  const small = await runTool('sci_viz_structure', {
    source: 'C:/Users/29411/dsh/.tmp_read/AF_O53740.pdb',
    label: '高亮与着色测试',
    highlight: ['12', '30', 'S50T'],
    style: 'ballstick',
    colorBy: 'resname',
  })
  void small
  await renderStructure(toolDocs.get('sci_viz_structure'), 'structure-highlight')
}

console.log('\n== 生成统计画面 ==')
const G = {
  wt: [8.2, 7.9, 8.5, 8.1, 7.7, 8.8, 8.3, 8.0, 8.4, 7.8],
  mut: [7.1, 6.8, 7.4, 7.0, 6.6, 7.5, 7.2, 6.9, 7.3, 6.7],
  high: [6.2, 6.0, 6.5, 5.9, 6.4, 6.1, 6.3, 6.0, 6.2, 5.8],
}
const chartCases = [
  ['chart-normal', { kind: 'normal', values: [...G.wt, ...G.mut], mu: 7.6, sigma: 0.7, title: '正态分布 · MIC 分布拟合' }],
  ['chart-ttest', { kind: 'ttest', groups: [{ label: '野生型 H37Rv', values: G.wt }, { label: 'katG S315T 突变株', values: G.mut }], title: 't 检验 · 野生型 vs 突变株' }],
  ['chart-ttest-paired', { kind: 'ttest', paired: true, groups: [{ label: '用药前', values: G.wt }, { label: '用药后', values: G.mut }], title: '配对 t 检验' }],
  ['chart-anova', { kind: 'anova', groups: [{ label: '敏感株', values: G.wt }, { label: '单耐药', values: G.mut }, { label: '耐多药', values: G.high }], title: '单因素方差分析 · 三组 MIC' }],
  ['chart-chisq', { kind: 'chisq', table: [[18, 7], [6, 19]], rowLabels: ['敏感', '耐药'], colLabels: ['含药', '对照'], title: '卡方检验 · 耐药与处理' }],
  ['chart-regression', { kind: 'regression', x: G.wt.concat(G.mut), y: G.wt.concat(G.mut).map((v, i) => v * 0.8 + (i % 3) * 0.3 - 1), title: '线性回归 · 两法一致性' }],
  ['chart-power', { kind: 'power', d: 0.5, power: 0.8, title: '功效曲线与样本量' }],
  ['chart-descriptives', { kind: 'descriptives', groups: [{ label: '野生型', values: G.wt }, { label: '突变株', values: G.mut }], title: '描述统计' }],
]
for (const [name, args] of chartCases) {
  await runTool('sci_viz_stats', args)
  await renderChart(toolDocs.get('sci_viz_stats'), name)
}

console.log('\n== 生成自定义绘图画面 ==')
{
  const xs = Array.from({ length: 40 }, (_, i) => i * 0.25)
  const curve = xs.map((x) => [x, 100 / (1 + Math.exp(-(x - 4)))])
  const noisy = xs.filter((_, i) => i % 2 === 0).map((x) => [x, 100 / (1 + Math.exp(-(x - 4))) + Math.sin(x * 3) * 4])
  await runTool('sci_viz_plot', {
    title: '剂量-反应曲线（sci_viz_plot 通用入口）',
    panels: [{
      kind: 'xy',
      title: '四参数逻辑曲线',
      xLabel: '药物浓度 (μg/mL)',
      yLabel: '抑制率 (%)',
      xDomain: [0, 10],
      yDomain: [0, 105],
      layers: [
        { type: 'rect', x0: 3.5, x1: 4.5, color: 'rgba(244,211,94,0.12)' },
        { type: 'line', pts: curve, color: '#4c9aff', width: 2.4 },
        { type: 'points', pts: noisy, color: '#f2a33c', r: 3 },
        { type: 'vline', x: 4, color: '#5ac8a8', dash: [5, 4], label: 'IC50 = 4.0' },
        { type: 'hline', y: 50, color: '#8fa3b8', dash: [4, 4], label: '50% 抑制' },
        { type: 'text', x: 7.4, y: 88, text: '拟合曲线', color: '#4c9aff', size: 12 },
      ],
      caption: '通用入口示例：矩形高亮 + 曲线 + 散点 + 参考线 + 文字注释，五类图元一次画全。',
    }],
  })
  await renderChart(toolDocs.get('sci_viz_plot'), 'chart-custom')
}

// 小尺寸下的表现（窗口被拖小）
await renderChart(toolDocs.get('sci_viz_stats'), 'chart-small', 430, 330)

// ---------------------------------------------------------------------------
// 回归断言：这几个坑都真踩过，加断言免得改回去
// ---------------------------------------------------------------------------
console.log('\n== 回归断言 ==')
{
  const checks = []
  const ok = (cond, label) => {
    checks.push({ cond: !!cond, label })
    console.log(`${cond ? '  ok  ' : ' FAIL '} ${label}`)
  }

  // 画布矮的时候不能让图表面板被静默跳过（实测踩过：3 面板 + 257px 高的画布，
  // 每个 cell 的绘图区被压到 45.5px，撞上 `box.h < 46` 的兜底判断 —— 只剩标题、图全没了，
  // 而且不报错。现在 resizeCanvas 会把画布撑到 chartMinHeight，外面滚动。）
  {
    // 显式造一份 3 面板的文档：单面板图在 257px 下本来就放得下，验不出这个问题
    await runTool('sci_viz_stats', {
      kind: 'anova',
      title: '矮画布回归测试',
      groups: [
        { label: 'A组', values: [4.78, 4.65, 3.98, 4.04, 3.44, 3.77] },
        { label: 'B组', values: [4.65, 6.92, 4.44, 6.16, 5.99, 6.67] },
        { label: 'C组（长名字测试）', values: [6.8, 5.91, 7.28, 7.51, 7.51, 7.74] },
      ],
    })
    const doc = toolDocs.get('sci_viz_stats')
    ok((doc.panels || []).length === 3, `回归用文档有 ${(doc.panels || []).length} 个面板`)
    const need = internals.chartMinHeight(doc, 1001)
    ok(need > 257, `3 面板图表的最小高度 = ${need}px > 257px（矮画布要撑高，不是压扁）`)
    const paint = (h) => {
      const g = guardContext(new SvgContext(1001, h))
      const res = internals.paintChart(g, doc, 1001, h)
      return { g, res }
    }
    const big = paint(need)
    ok(big.res.skipped === 0, `按最小高度渲染不跳过任何面板（skipped=${big.res.skipped}）`)
    ok(big.g.body.length > 20, `画面元素 ${big.g.body.length} 个（不是只剩标题的空图）`)
    const small = paint(257)
    ok(small.res.skipped > 0,
      `矮画布确实会跳过面板（skipped=${small.res.skipped}）—— 所以撑高是必需的，不是保险`)
    // 长 x 轴标签要撑开轴带，否则会压到下面的图注上
    const forest = (doc.panels || []).find((p) => (p.xTickLabels || []).some((s) => String(s).length > 12))
    ok(!!forest, '这份文档里有一个带长标签的森林图面板')
    if (forest) {
      const axisH = internals.chartAxisHeight({ panels: [forest] })
      ok(axisH > 40, `长标签把轴带撑到 ${axisH}px（默认只有 40px，会压到图注上）`)
    }
  }

  // 用多链结构测「只显示这些链」
  await runTool('sci_viz_structure', {
    source: 'C:/Users/29411/dsh/.tmp_read/af3/fold_2304plus3unit_model_0.cif',
    label: '多链测试',
  })
  const multi = toolDocs.get('sci_viz_structure')

  const all = internals.createStructureView(multi)
  ok(all.view.visibleChains === null, '不给 chains 时显示全部链')
  const two = multi.chains.filter((c) => c.residueCount > 0).slice(0, 2).map((c) => c.id)
  const filtered = internals.createStructureView({ ...multi, view: { ...multi.view, chains: two } })
  ok(
    Array.isArray(filtered.view.visibleChains) && filtered.view.visibleChains.join() === two.join(),
    `视图参数 chains=[${two.join(',')}] 真的进了 visibleChains（曾经被丢掉，过滤永远无效）`,
  )
  const nAll = internals.buildPrimitives(all).length
  const nFew = internals.buildPrimitives(filtered).length
  ok(nFew < nAll, `过滤后绘制原语从 ${nAll} 降到 ${nFew}`)

  // focus 必须真的把镜头推进去：对比同一个多链结构在「全局取景」与「聚焦取景」下的缩放矩阵
  const midCa = all.ca[Math.floor(all.ca.length / 2)]
  const midAtom = all.atoms[midCa.index]
  const focusWorld = [
    midAtom.x + multi.bbox.center[0],
    midAtom.y + multi.bbox.center[1],
    midAtom.z + multi.bbox.center[2],
  ]
  const focused = internals.createStructureView({ ...multi, view: { ...multi.view, focus: focusWorld } })
  ok(
    focused.focusAtoms && focused.focusAtoms.length >= 8,
    `focus 圈出 ${focused.focusAtoms ? focused.focusAtoms.length : 0} 个邻近原子（≥8 才启用聚焦取景）`,
  )

  // 直接问投影函数要缩放比：比在 SVG 里正则找矩阵可靠得多
  const scaleOf = (view) => {
    delete view._fitScale // 别让上一帧的平滑值影响测量
    return internals.projection(view, 400, 300, internals.rotationMatrix(view.view.yaw, view.view.pitch)).scale
  }
  const sAll = scaleOf(all)
  const sFocus = scaleOf(focused)
  ok(sFocus > sAll * 1.2, `focus 后取景缩放 ${sFocus.toFixed(2)} > 全局 ${sAll.toFixed(2)}（真的推进去了）`)
  const focusDoc = { ...multi, view: { ...multi.view, focus: focusWorld } }
  await renderStructure(focusDoc, 'structure-focused')
  await renderStructure({ ...multi, view: { ...multi.view, chains: two } }, 'structure-chain-filter')

  // 单样本的描述统计不能给出 NaN 置信区间
  const one = N.describe([5])
  ok(Number.isFinite(one.ci[0]) && Number.isFinite(one.ci[1]), `n=1 的 95%CI = [${one.ci[0]}, ${one.ci[1]}] 而不是 NaN`)

  // N 端 / C 端高亮（用户明确点名要的功能，行为必须钉住）
  {
    const chains = multi.chains.filter((c) => c.residueCount > 0)
    const off = internals.createStructureView({ ...multi, view: { ...multi.view, termini: false } })
    const on = internals.createStructureView({ ...multi, view: { ...multi.view, termini: true } })
    ok(off.highlight.every((h) => h.role === 'site'), '默认不开末端：高亮里只有位点')
    ok(on.highlight.length > off.highlight.length,
      `开启末端后高亮条目 ${off.highlight.length} → ${on.highlight.length}（${chains.length} 条链）`)
    const c0 = chains[0]
    const nEntry = on.highlight.find((h) => h.role === 'nterm' && h.chain === c0.id)
    const cEntry = on.highlight.find((h) => h.role === 'cterm' && h.chain === c0.id)
    ok(nEntry && nEntry.resSeq === c0.first, `链 ${c0.id} N 端 = ${nEntry && nEntry.resSeq}（首残基 ${c0.first}）`)
    ok(cEntry && cEntry.resSeq === c0.last, `链 ${c0.id} C 端 = ${cEntry && cEntry.resSeq}（末残基 ${c0.last}）`)
    on.setTermini(false)
    ok(!on.highlight.some((h) => h.role !== 'site'), '面板开关能关掉末端')
    on.setTermini(true)
    ok(on.highlight.some((h) => h.role === 'nterm') && on.highlight.some((h) => h.role === 'cterm'),
      '面板开关能重新打开，且 N/C 两类都在')
    await renderStructure({ ...multi, view: { ...multi.view, termini: true } }, 'structure-termini')
  }

  // 粘贴数据的解析器：面板上「运行」按钮的入口，规则必须钉住
  {
    const P = internals.parseDataTable
    const g = P('对照组\t8.2 7.9 8.5\n用药组\t7.1 6.8 7.4', 'ttest')
    ok(g.groups && g.groups.length === 2 && g.groups[0].label === '对照组' && g.groups[0].values.length === 3,
      '带标签的粘贴 → 两组')
    const one = P('# 注释\n1.2\n2.4\n3.6', 'descriptives')
    ok(Array.isArray(one.values) && one.values.length === 3, '纯数字一列 → values（# 开头被忽略）')
    const reg = P('1 2.4\n2 3.1\n3 4.0', 'regression')
    ok(Array.isArray(reg.x) && Array.isArray(reg.y) && reg.x.length === 3, '纯数字两列 + regression → x/y')
    const tab = P('18 7\n6 19', 'chisq')
    ok(Array.isArray(tab.table) && tab.table.length === 2 && tab.table[0].length === 2, '数字矩阵 + chisq → 计数表')
    const cols = P('1 10\n2 20\n3 30', 'ttest')
    ok(cols.groups && cols.groups.length === 2, '多列无标签 + ttest → 按列分组')
    const pw = P('0.5 0.9', 'power')
    ok(pw.d === 0.5 && pw.power === 0.9, 'power → 读 d / power')
    let threw = ''
    try { P('', 'ttest') } catch (e) { threw = e.message }
    ok(/还没有数据/.test(threw), `空输入给出可读错误：${threw}`)
    threw = ''
    try { P('1 2\n3', 'chisq') } catch (e) { threw = e.message }
    ok(/计数表/.test(threw), `卡方列数不齐时报错：${threw}`)
  }

  // kind=raw 必须从 stats 里消失（它并进了 sci_viz_plot）
  const statKinds = tools.get('sci_viz_stats').parameters.properties.kind.enum
  ok(!statKinds.includes('raw'), `kind 枚举 = ${statKinds.join('/')}`)
  ok(!!tools.get('sci_viz_plot').parameters.properties.panels, 'sci_viz_plot 才有 panels 参数')

  const failed = checks.filter((c) => !c.cond)
  if (failed.length) {
    console.log(`\n回归断言失败 ${failed.length} 项`)
    process.exitCode = 1
  }
}

console.log('\n== 结果 ==')
let total = 0
for (const a of artifacts) {
  total += a.bytes
  console.log(`  ${a.name.padEnd(26)} ${String(a.bytes).padStart(7)} B  ${a.png}`)
}
console.log(`共 ${artifacts.length} 张，PNG 合计 ${(total / 1024).toFixed(0)} KB`)
console.log(`结构面板原语数：${internals.buildPrimitives(internals.createStructureView(baseDoc)).length}`)
rmSync(sandbox, { recursive: true, force: true })

// 这些 PNG/SVG 加起来约 10 MB —— 只是给人眼看的中间产物，默认用完就删。
// 想自己打开看图就加 --keep。
if (process.argv.includes('--keep')) {
  console.log(`保留在 ${OUT}（--keep）`)
} else {
  rmSync(OUT, { recursive: true, force: true })
  console.log('已删除中间产物（加 --keep 可保留 PNG/SVG 自行查看）')
}
